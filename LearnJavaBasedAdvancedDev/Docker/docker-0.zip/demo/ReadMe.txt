To build(assuming docker is installed and you are on path ..../demo/ in terminal):
docker build --tag=demo:latest .

To run the image(in a container):
docker run -d -p 8080:8081 demo:latest

To test if it's running:
In browser, open localhost:8080/test/hello, you should see a message Hello.

To Stop:
docker ps, will give you container Id
docker stop <container-id>, will stop the container.

Note:- Alpine based jdk was not used as a stable alpine jdk 11 was not available. So, went with slim-buster.